# DINKANxMALLU Website

## Files
- `index.html` — main website
- `css/style.css` — all styling and RGB effects
- `js/script.js` — live status, copy-IP button, particles
- `images/rgb-minecraft-bg.svg` — local RGB background

## Run locally
Double-click `index.html` to open it in a browser.

## GitHub Pages
Upload the entire folder to your repository. Keep the folder structure unchanged:
- index.html
- css/style.css
- js/script.js
- images/rgb-minecraft-bg.svg

Then enable GitHub Pages from the repository's Settings → Pages.

## Server
IP: DINKANxMALLU.aternos.me
Discord: https://discord.gg/xCVpZvMnR

The live player counter uses the public mcsrvstat.us API and requires an internet connection.
