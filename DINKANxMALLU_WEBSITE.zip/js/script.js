const SERVER_IP = "DINKANxMALLU.aternos.me";

function copyIP(){
  navigator.clipboard.writeText(SERVER_IP).then(()=>{
    const button=document.querySelector(".hero .btn");
    const oldText=button.innerHTML;
    button.innerHTML="✅ IP COPIED!";
    setTimeout(()=>button.innerHTML=oldText,2000);
  }).catch(()=>alert("Server IP: "+SERVER_IP));
}

async function checkServer(){
  const status=document.getElementById("serverStatus");
  const players=document.getElementById("playerCount");
  status.textContent="CHECKING...";
  status.style.color="#00ffff";
  players.textContent="Checking live players...";

  try{
    const response=await fetch(
      "https://api.mcsrvstat.us/3/"+encodeURIComponent(SERVER_IP)
    );
    if(!response.ok) throw new Error("API error");
    const data=await response.json();

    if(data.online){
      status.textContent="ONLINE";
      status.style.color="#00ff88";
      const online=data.players?.online ?? 0;
      const max=data.players?.max ?? "?";
      players.innerHTML="🟢 Players Online: <strong>"+online+" / "+max+"</strong>";
    }else{
      status.textContent="OFFLINE";
      status.style.color="#ff405c";
      players.textContent="🔴 The server is currently offline.";
    }
  }catch(error){
    status.textContent="STATUS UNAVAILABLE";
    status.style.color="#ffaa00";
    players.textContent="⚠️ Live status could not be loaded.";
  }
}

checkServer();
setInterval(checkServer,30000);

const canvas=document.getElementById("particles");
const ctx=canvas.getContext("2d");
let particles=[];

function resizeCanvas(){
  canvas.width=window.innerWidth;
  canvas.height=window.innerHeight;
}
resizeCanvas();
window.addEventListener("resize",resizeCanvas);

function createParticles(){
  particles=[];
  const count=Math.min(90,Math.floor(window.innerWidth/15));
  for(let i=0;i<count;i++){
    particles.push({
      x:Math.random()*canvas.width,
      y:Math.random()*canvas.height,
      size:Math.random()*2+.5,
      speed:Math.random()*.5+.1,
      hue:Math.random()*360,
      alpha:Math.random()*.6+.2
    });
  }
}
createParticles();

function animateParticles(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  for(const p of particles){
    p.y-=p.speed;
    p.hue+=.5;
    if(p.y<-10){
      p.y=canvas.height+10;
      p.x=Math.random()*canvas.width;
    }
    ctx.beginPath();
    ctx.arc(p.x,p.y,p.size,0,Math.PI*2);
    ctx.fillStyle=`hsla(${p.hue},100%,65%,${p.alpha})`;
    ctx.shadowBlur=15;
    ctx.shadowColor=`hsla(${p.hue},100%,65%,.8)`;
    ctx.fill();
  }
  requestAnimationFrame(animateParticles);
}
animateParticles();
